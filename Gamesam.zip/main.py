password = " "
while password != "sameer":
  password = input("Enter the Password: ")
  if password == "sameer":
    print("Congrats you enter the Correct password")
  else:
    print("PLease Try again")